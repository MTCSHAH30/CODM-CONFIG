[/Script/ShadowTrackerExtra.STExtraBaseCharacter]
VRecoil=20.00
HRecoil=20.00
AccessoriesHRecoilFactor=20.00
AccessoriesVRecoilFactor=20.00
VRecoil=70
HRecoil=70
Cvars=True
Anticheat=False
Paks=True
Pandora=True
AccessoriesHRecoilFactor=70
AccessoriesVRecoilFactor=70
AccessoriesDeviationFactor=70
BulletFireSpeed=20.00
CharacterHead="20.00"
CharacherBody=20.00
CharacterCvars=20.00
ClintHitPartAimAssist=20.00
LogAntiCheat=Log
AimAssist=True
HitPartKick=True
AimAnimation=False
UseShootVerifyEx=True
AccessoriesRecoveryFactor=True
AimAnimation=False
ClientHitPartJudgment=True
UseShootVerifyEx=True

[/Script/ShadowTrackerExtra.STExtraBaseCharacter]
AimAssist=20.00u
Target=("body")=True
AutoAimEnable="Aim_Assist"(True)=Value="20.00u"

[/Script/ShadowTrackerExtra.ShootWeaponEntity]
IsHeadShot=True
CharacterHead=True

[/Script/ShadowTrackerExtra.ShootWeaponEntity]
Flag=False
HitPos=0000.3
hitPhysMatType=ObjectHit
IgnoreTakeDamage=Indicator
AnimationKick=Enable
AccessoriesRecoveryFactor=True
AccessoriesHRecoilFactor=True
AccessoriesVRecoilFactor=True
AccessoriesDeviationFactor=True

[/Script/ShadowTrackerExtra.STExtraBaseCharacter]
ClientHitPartJudgment=Enable
UseShootVerifyEx=True

[/Script/ShadowTrackerExtra.STExtraGameInstance]
+SwitchesInMaps=(MapName="shooting_range4",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="CODM_Forest",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="CODM_Desert",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="CODM_Savage_Main",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="DihorOtok_Main",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="TD_Logging_Camp_Main",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="PVE_Infection_main",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="HP_City_Main",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="TD_Ruins_Half",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="TD_Factory_Depot_Mian",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="VehicleBattle_TDM_CODM_Forest",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="SocialIsland_Main",Switches=((Key="t.MaxFPS",Value="90")))
+SwitchesInMaps=(MapName="SocialIsland_Private_Main",Switches=((Key="t.MaxFPS",Value="90")))

[EncryptCode]
3F18170D1C0B1031181A12
+CVars=3F2C3A323A36292129382A2D3C2B2A
+CVars=2D3C353C3E2B38343F38372D3C2B3031383A32


#Junskiee official 
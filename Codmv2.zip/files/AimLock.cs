var aimAssist = 1;
var range = 100.0;
var aimSpeed = 100.0;
var Crosshair = "Actor";
var aimShooterGame = 100.0;
var aimBattleRoyaleGame = 100.0;


function Update(){
    var ray = Camera.main.ScreenPointToRay (Input.Touch);
    var hit : RaycastHit;
    var damage : Raycast
    if (collider.Raycast (ray, hit, range)) {
        //Debug.DrawLine (ray.origin, hit.point);
        if (hit.collider.tag == "target") {
            aimAssist = 1;
        } else {
            aimAssist = 0;
        }
     }
   // do your movement controls
   var translation = Input.GetAxis ("Vertical") * moveSpeed;
    moveSpeed = 100.0f;
   var rotation = Input.GetAxis ("Horizontal") * aimSpeed;
    aimSpeed = 100.0f;
 };

function Update () {
	//create a Vector3 representing the forward direction
	var forward: Vector3 = spawnLocation.TransformDirection(Vector3.forward) * 100;

	//draw debug ray straight ahead
	Debug.DrawRay(transform.position, forward, Color.green);

	//shoot fireball
	if(Input.GetButtonDown("Fire2")){
		var spell = Instantiate(fireballPrefab, spawnLocation.position, spawnLocation.rotation);

		//raycast - anything there?
		var hit: RaycastHit;													//create hit object to store raycast results
		if(Physics.Raycast(spawnLocation.position, forward, hit)){				//if raycast hits something...
			var enemy = hit.collider.gameObject;								//get the GameObject that was hit
			var eh = enemy.GetComponent(EnemyHealth);							//get the EnemyHealth component from enemy
			eh.health -= 100.0f;													//decrease health by 0.5f;

			//change value on screen
			var ehDisplay = GameObject.Find("Enemy_HealthDisplay");
			var ehText = ehDisplay.GetComponent(GUIText);
			ehText.text = "Enemy Health: " + eh.health;
		}
	}
}
Junskiee